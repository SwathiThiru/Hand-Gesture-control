<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>
<style>
a:link {
    text-decoration: none;
}

a:visited {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

a:active {
    text-decoration: underline;
}
</style>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <th width="9%" bgcolor="#D1EEFE" scope="col"><p><a href="memberlist.php"><strong>Member list</strong></a></p></th>
    <th width="11%" bgcolor="#D1EEFE" scope="col"><a href="gallerylist.php"><strong>Gallery</strong></a></th>
    <th width="12%" bgcolor="#D1EEFE" scope="col"><strong><a href="productlist.php">Products</a></strong></th>
    <th width="10%" bgcolor="#D1EEFE" scope="col"><a href="maincategorylist.php">Main Category</a></th>
    <th width="12%" bgcolor="#D1EEFE" scope="col"><strong><a href="subcategorylist.php">Sub Category</a></strong></th>
    <th width="9%" bgcolor="#D1EEFE" scope="col"><strong>Payment</strong></th>
    <th width="14%" bgcolor="#D1EEFE" scope="col"><strong><a href="changepassword.php">Change password</a></strong></th>
    <th width="12%" bgcolor="#D1EEFE" scope="col"><strong><a href="logout.php">Logout</a></strong></th>
  </tr>
</table>

<p><br>
</p>
</body>
</html>