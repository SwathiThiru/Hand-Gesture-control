<?php 
error_reporting(E_ERROR);

session_start();
if(session_destroy())
{
header('location:product.php');
}


?>

