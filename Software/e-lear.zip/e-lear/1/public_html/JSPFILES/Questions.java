package Q1;

import java.io.*;

public class Questions implements Serializable
{
public String cid,qid,qd,op1,op2,op3,op4,ans,ar;
public Questions()
{
cid=null;
qid=null;
qd=null;
op1=null;
op2=null;
op3=null;
op4=null;
ans=null;
ar=null;
}
}
